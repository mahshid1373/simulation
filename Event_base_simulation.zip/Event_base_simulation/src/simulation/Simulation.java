package simulation;

/**
 * Created by Mahshid on 5/18/2016.
 */
public class Simulation extends Event {
    protected final void actions() {}
}