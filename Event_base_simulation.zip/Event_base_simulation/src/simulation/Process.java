package simulation;

import javaCoroutine.Coroutine;
import simset.Head;
import simset.Link;

import static javaCoroutine.Coroutine.resume;

/**
 * Created by Mahshid on 5/19/2016.
 */

public abstract class Process extends Link {
    protected abstract void actions();
    private final Coroutine myCoroutine = new Coroutine() {
        protected void body() {
            if (MAIN == null)
                MAIN = Process.this;
            actions();
            TERMINATED = terminated = true;
            if (Process.this == MAIN) {
                while (SQS.SUC != SQS)
                    SQS.SUC.cancel();
                MAIN = null;
                return;
            }
            passivate();
        }
    };
    private static Process PRED, SUC;
    private static double EVTIME;
    private boolean TERMINATED;
    private final static Process SQS = new Process() {
        { EVTIME = -1; PRED = SUC = this; }
        protected void actions() {}
    };
    private static Process MAIN;
    public final boolean idle() {
        return SUC == null;
    }
    public final boolean terminated() {
        return TERMINATED;
    }
    public final double evTime() {
        if (idle())
            error("No evTime for idle process");
        return EVTIME;
    }
    public final Process nextEv() {
        return SUC == SQS ? null : SUC;
    }
    public static final Process current() {
        return SQS.SUC != SQS ? SQS.SUC : null;
    }
    public static final double time() {
        return SQS.SUC != SQS ? SQS.SUC.EVTIME : 0;
    }
    public static final Process main() { return MAIN; }
    private static void error(String msg) {
        throw new RuntimeException(msg);
    }
    public static final void hold(double t) {
        if (SQS.SUC == SQS)
            error("Hold: SQS is empty");
        Process Q = SQS.SUC;
        if (t > 0)
            Q.EVTIME += t;
        t = Q.EVTIME;
        if (Q.SUC != SQS && Q.SUC.EVTIME <= t) {
            Q.cancel();
            Process P = SQS.PRED;
            while (P.EVTIME > t)
                P = P.PRED;
            Q.scheduleAfter(P);
            resume(SQS.SUC);
        }
    }
    public static final void passivate() {
        if (SQS.SUC == SQS)
            error("Passivate: SQS is empty");
        Process CURRENT = SQS.SUC;
        CURRENT.cancel();
        if (SQS.SUC == SQS)
            error("passivate causes SQS to become empty");
        resume(SQS.SUC);
    }
    public static final void wait(Head q) {
        if (SQS.SUC == SQS)
            error("Wait: SQS is empty");
        current().into(q);
        Process CURRENT = SQS.SUC;
        CURRENT.cancel();
        if (SQS.SUC == SQS)
            error("wait causes SQS to become empty");
        resume(SQS.SUC);
    }
    public static final void cancel(Process p) {
        if (p == null || p.SUC == null)
            return;
        Process CURRENT = SQS.SUC;
        p.cancel();
        if (SQS.SUC != CURRENT)
            return;
        if (SQS.SUC == SQS)
            error("cancel causes SQS to become empty");
        resume(SQS.SUC);
    }
    private static final class At {}
    private static final class Delay {}
    private static final class Before {}
    private static final class After {}
    private static final class Prior {}
    public static final At at = new At();
    public static final Delay delay = new Delay();
    public static final Before before = new Before();
    public static final After after = new After();
    public static final Prior prior = new Prior();
    private static final int direct_code = 0;
    private static final int at_code = 1;
    private static final int delay_code = 2;
    private static final int before_code = 3;
    private static final int after_code = 4;
    private static final void activat(boolean reac, Process x,
                                      int code, double t,
                                      Process y, boolean prio) {
        if (x == null || x.TERMINATED ||
                (!reac && x.SUC != null))
            return;
        Process CURRENT = SQS.SUC, P = null;
        double NOW = time();
        switch(code) {
            case direct_code:
                if (x == CURRENT)
                    return;
                t = NOW; P = SQS;
                break;
            case delay_code:
                t += NOW;
            case at_code:
                if (t <= NOW) {
                    if (prio && x == CURRENT)
                        return;
                    t = NOW;
                }
                break;
            case before_code:
            case after_code:
                if (y == null || y.SUC == null) {
                    x.cancel();
                    if (SQS.SUC == SQS)
                        error("reactivate causes SQS " +
                                "to become empty");
                    return;
                }
                if (x == y)
                    return;
                t = y.EVTIME;
                P = code == before_code ? y.PRED : y;
        }
        if (x.SUC != null)
            x.cancel();
        if (P == null) {
            for (P = SQS.PRED; P.EVTIME > t; P = P.PRED)
                ;
            if (prio)
                while (P.EVTIME == t)
                    P = P.PRED;
        }
        x.EVTIME = t;
        x.scheduleAfter(P);
        if (SQS.SUC != CURRENT)
            resume(current());
    }
    public static final void activate(Process p) {
        activat(false, p, direct_code, 0, null, false);
    }
    public static final void activate(Process p,
                                      At at, double t) {
        activat(false, p, at_code, t, null, false);
    }
    public static final void activate(Process p,
                                      At at, double t, Prior prior) {
        activat(false, p, at_code, t, null, true);
    }
    public static final void activate(Process p,
                                      Delay delay, double t) {
        activat(false, p, delay_code, t, null, false);
    }
    public static final void activate(Process p,
                                      Delay d, double t, Prior prior) {
        activat(false, p, delay_code, t, null, true);
    }
    public static final void activate(Process p1,
                                      Before before, Process p2) {
        activat(false, p1, before_code, 0, p2, false);
    }
    public static final void activate(Process p1,
                                      After after, Process p2) {
        activat(false, p1, after_code, 0, p2, false);
    }
    public static final void reactivate(Process p) {
        activat(true, p, direct_code, 0, null, false);
    }
    public static final void reactivate(Process p,
                                        At at, double t) {
        activat(true, p, at_code, t, null, false);
    }
    public static final void reactivate(Process p,
                                        At at, double t, Prior prior) {
        activat(true, p, at_code, t, null, true);
    }
    public static final void reactivate(Process p,
                                        Delay delay, double t) {
        activat(true, p, delay_code, t, null, false);
    }
    public static final void reactivate(Process p,
                                        Delay d, double t, Prior prior) {
        activat(true, p, delay_code, t, null, true);
    }
    public static final void reactivate(Process p1,
                                        Before before, Process p2) {
        activat(true, p1, before_code, 0, p2, false);
    }
    public static final void reactivate(Process p1,
                                        After after, Process p2) {
        activat(true, p1, after_code, 0, p2, false);
    }
    private final void scheduleAfter(Process p) {
        PRED = p;
        SUC = p.SUC;
        p.SUC = SUC.PRED = this;
    }
    private final void cancel() {
        PRED.SUC = SUC;
        SUC.PRED = PRED;
        PRED = SUC = null;
    }
}