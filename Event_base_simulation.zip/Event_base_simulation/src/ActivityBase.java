import simulation.Activity;
import simulation.Simulation;
import simulation.Activity;
import simset.*;
import random.*;
/**
 * Created by Mahshid on 5/19/2016.
 */
public class ActivityBase {
    public class CarWashSimulation extends Simulation {
        int noOfCarWashers;
        double simPeriod = 200;
        Head tearoom = new Head();
        Head waitingLine = new Head();
        Random random = new Random(5);
        int noOfCustomers, maxLength;
        double throughTime;
        CarWashSimulation(int n) {
            noOfCarWashers = n;
            for (int i = 1; i <= noOfCarWashers; i++)
                new CarWasher().into(tearoom);
            new CarArrival();
            runSimulation(simPeriod + 1000000);
            report();
        }
        void report() { ... }
        class CarWasher extends Link {}
        class Car extends Link { ... }
        class CarWashing extends Activity { ... }
        class CarArrival extends Activity { ... }
        public static void main(String args[]) {
            new CarWashSimulation(1);
            new CarWashSimulation(2);
        }
    }


    class CarArrival extends Activity
    public boolean condition() {
        return true;
    }
    public void startActions() {
        Car theCar = new Car();
        theCar.into(waitingLine);
        new CarWashing(theCar);
        int qLength = waitingLine.cardinal();
        if (maxLength < qLength)
            maxLength = qLength;
    }
    public double duration() {
        return random.negexp(1/11.0);
    }
    public void finishActions() {
        if (time() <= simPeriod)
            new CarArrival();
    }


class CarWashing extends Activity {
    Car theCar;
    CarWasher theCarWasher;
    CarWashing(Car c) { theCar = c; }
    public boolean condition() {
        return theCar == (Car) waitingLine.first() &&
                !tearoom.empty();
    }
    public void startActions() {
        theCar.out();
        theCarWasher = (CarWasher) tearoom.first();
        theCarWasher.out();
    }
    public double duration() {
        return 10;
    }
    public void finishActions() {
        theCarWasher.into(tearoom);
        noOfCustomers++;
        throughTime += time() - theCar.entryTime;
    }
}
}
