package javaCoroutine;

/**
 * Created by Mahshid on 5/19/2016.
 */
public abstract class Coroutine {
    protected abstract void body();
    public static final void resume(Coroutine next) {
        if (next == null)
            error("resume non-existing coroutine");
        if (next.terminated)
            error("resume terminated coroutine");
        if (next.caller != null)
            error("resume attached coroutine");
        if (next == current)
            return;
        while (next.callee != null)
            next = next.callee;
        next.enter();
    }
    public static final void call(Coroutine next) {
        if (next == null)
            error("call non-existing coroutine");
        if (next.terminated)
            error("call terminated coroutine");
        if (next.caller != null)
            error("call attached coroutine");
        if (current != null)
            current.callee = next;
        next.caller = current;
        while (next.callee != null)
            next = next.callee;
        if (next == current)
            error("call operating coroutine");
        next.enter();
    }
    public static final void detach() {
        Coroutine next = current.caller;
        if (next != null) {
            current.caller = next.callee = null;
            next.enter();
        }
        else if (main != null && current != main)
            main.enter();
    }
    public static final Coroutine currentCoroutine() {
        return current;
    }
    public static final Coroutine mainCoroutine() {
        return main;
    }
    private final class Runner extends Thread {
        Coroutine myCoroutine;
        Runner nextFree;
        Runner(Coroutine c) {
            myCoroutine = c;
            setDaemon(true);
        }
        public void run() {
            while (true) {
                myCoroutine.body();
                if (!myCoroutine.terminated) {
                    myCoroutine.terminated = true;
                    detach();
                }
                if (myCoroutine == Coroutine.main) {
                    Coroutine.current = null;
                    synchronized(Runner.class) {
                        Coroutine.main = null;
                        Runner.class.notify();
                    }
                    return;
                }
                nextFree = firstFree;
                firstFree = this;
                try {
                    synchronized(this) {
                        wait();
                    }
                } catch (InterruptedException e) {}
            }
        }
        void go() {
            if (!isAlive())
                start();
            else
                synchronized(this) {
                    notify();
                }
        }
    }
    private static void error(String msg) {
        throw new RuntimeException(msg);
    }
    private static Coroutine current, main;
    private Coroutine caller, callee;
    protected boolean terminated;
    private Runner myRunner;
    private static Runner firstFree;
    private void enter() {
        if (myRunner == null) {
            if (firstFree == null)
                myRunner = new Runner(this);
            else {
                myRunner = firstFree;
                firstFree = firstFree.nextFree;
                myRunner.myCoroutine = this;
            }
        }
        if (main == null) {
            main = current = this;
            myRunner.go();
            synchronized(Runner.class) {
                try {
                    while (main != null)
                        Runner.class.wait();
                } catch (InterruptedException e) {}
            }
            return;
        }
        Coroutine old_current = current;
        synchronized(old_current.myRunner) {
            current = this;
            myRunner.go();
            if (old_current.terminated)
                return;
            try {
                old_current.myRunner.wait();
            } catch(InterruptedException e) {}
        }
    }
}