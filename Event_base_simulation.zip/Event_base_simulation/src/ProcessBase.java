import random.Random;
import simulation.*;
import simulation.Process;
import simset.*;
/**
 * Created by Mahshid on 5/19/2016.
 */

public class ProcessBase extends Process {
    int noOfTicketBuyer;
    double simPeriod = 200;//=show-time
    Head ticketBuyerIDLEQueue = new Head();
    Head reserveWaitingLine = new Head();
    Head cancelWaitingLine = new Head();
    Random random = new Random(5);
    double throughTime;
    int noOfCustomers, maxReserveLength, maxCancelLength;

    ProcessBase(int n) {
        noOfTicketBuyer = n;
    }

    public void actions() {
        for (int i = 1; i <= noOfTicketBuyer; i++)
            new ticketBuyer('a').into(ticketBuyerIDLEQueue);
        activate(new customerReserveGenerator());
        activate(new customerCancelGenerator());
        hold(simPeriod + 1000000);//simperiod == show-time
        report();
    }

    void report(){

    }

    class Customer extends Process {
        Head queue ;
        char typeOfQueue;
        public Customer(char type) {
            this.typeOfQueue = type;
            if (typeOfQueue == 'c')
                queue = cancelWaitingLine;
            else if (typeOfQueue == 'r')
                queue = reserveWaitingLine;
            else
                System.out.println("a new ticketBuyer added");
        }

        public void actions() {
            double entryTime = time();
            if (typeOfQueue == 'c')
                into(cancelWaitingLine);
            else if (typeOfQueue == 'r')
                into(reserveWaitingLine);

            int qReserveLength = reserveWaitingLine.cardinal();
            int qCancelLength  = cancelWaitingLine.cardinal();

            if (maxReserveLength < qReserveLength)
                maxReserveLength = qReserveLength;
            if (maxCancelLength < qCancelLength)
                maxCancelLength = qCancelLength;

            if (!ticketBuyerIDLEQueue.empty())
                activate((ticketBuyer) ticketBuyerIDLEQueue.first());

            activate(new customerExistanceOfReserveQueue(this));

            passivate();
            noOfCustomers++;
            throughTime += time() - entryTime;
        }
    }

    class ticketBuyer extends Process {
        char typeOfQueue;
        Customer served;
        int holdTime;
        public ticketBuyer(char type) {
            this.typeOfQueue = type;
            if (type == 'c')
                holdTime = 10;//sell-duration
            else if (type == 'r')
                holdTime = 10;//cancel-duration
        }

        public void actions() {
            while (true) {
                out();
                while (!cancelWaitingLine.empty() || !reserveWaitingLine.empty()) {
                    if (typeOfQueue == 'c') {
                        served =
                                (Customer) cancelWaitingLine.first();
                    }
                    else if (typeOfQueue == 'r'){
                        served =
                                (Customer) reserveWaitingLine.first();
                    }
                    served.out();

                    hold(holdTime);
                    activate(served);
                }
                wait(ticketBuyerIDLEQueue);
            }
        }
    }

    class customerReserveGenerator extends Process {
        public void actions() {
            while (time() <= simPeriod) {
                activate(new Customer('r'));
                hold(random.negexp(1 / 11.0));//reserve arrival-mean
            }
        }
    }

    class customerCancelGenerator extends Process {
        public void actions() {
            while (time() <= simPeriod) {
                activate(new Customer('c'));
                hold(random.negexp(1/11.0));//cancel arrival-mean
            }
        }
    }

    class customerExistanceOfReserveQueue extends Process {
        Customer theCustomer;
        public customerExistanceOfReserveQueue(Customer theCustomer) {
            this.theCustomer = theCustomer ;
        }

        public void actions() {
            while (time() <= simPeriod) {

                hold(random.negexp(1 / 11.0));//exit-mean
                if (isCommingOut())
                    cancel(theCustomer);
                else
                    activate(theCustomer);
            }
        }

        private boolean isCommingOut() {
            return false;
        }
    }

    public static void main(String args[]) {
        activate(new ProcessBase(1));//1= agent-num
    }
}