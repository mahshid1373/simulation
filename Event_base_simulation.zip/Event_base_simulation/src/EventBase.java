import simset.*;
import simulation.Event;
import simulation.Simulation;
import random.*;

//import java.util.Random;

/**
 * Created by Mahshid on 5/18/2016.
 */

public class EventBase extends Simulation {
    double simPeriod = 200;//=show-time
    Head ticketBuyerIDLEQueu = new Head();
    Head reserveWaitingLine = new Head();
    Head cancelWaitingLine = new Head();
    Random random = new Random(5);
    int noOfCustomers , maxReserveLength , maxCancelLength;
    double throughTime;

    EventBase(int n){
        noOfCustomers = n;
        for (int i = 1; i <= noOfCustomers; i++) {
            new ticketBuyer().into(ticketBuyerIDLEQueu);
        }
        new CustomerReserveArrival().schedule(0);
        runSimulation(simPeriod + 1000000);
    }

    public static void main(String[] args) {
        new EventBase(3);//3= agent_num
    }

    public class ticketBuyer extends Link {}

    public class Customer extends Link {
        double entryTime = time();//the time each customer enter the queue
    }

    public class CustomerReserveArrival extends Event {
        public void actions(){
            if (time() <= simPeriod) {
                Customer theCustomer = new Customer();
                theCustomer.into(reserveWaitingLine);
                int qLength = reserveWaitingLine.cardinal();
                if (maxReserveLength < qLength)
                    maxReserveLength = qLength;
                if (!ticketBuyerIDLEQueu.empty())
                    new StartBuyingTicket('r').schedule(time());
                new CustomerReserveArrival().schedule(
                        time() + random.negexp(1/11.0));//11 = arrival-mean
                new CustomerExistanceOfReserveQueue(theCustomer).schedule(
                        time() + random.negexp(1/11));//11 = exit-rate
            }
        }
    }


    class StartBuyingTicket extends Event {
        Head queue ;
        int timeduration ;
        public StartBuyingTicket(char typeOfQueue) {
            if (typeOfQueue == 'c'){
                queue = cancelWaitingLine;
                timeduration = 10;//cancel-duration
            }
            else {
                queue = reserveWaitingLine;
                timeduration = 10;//sell-duration
            }
        }

        public void actions() {
            ticketBuyer theticketBuyer =
                    (ticketBuyer) ticketBuyerIDLEQueu.first();
            theticketBuyer.out();
            Customer theCustomer = (Customer) queue.first();
            theCustomer.out();
            new StopBuyingTicket(theticketBuyer, theCustomer).
                    schedule(time() + timeduration);//10 = sell-duration   or cancel-duration
        }
    }

    class StopBuyingTicket extends Event {
        ticketBuyer theTicketBuyer;
        Customer theCustomer;
        StopBuyingTicket(ticketBuyer tb, Customer c)
        {
            theTicketBuyer = tb;
            theCustomer = c;
        }
        public void actions() {
            theTicketBuyer.into(ticketBuyerIDLEQueu);
            if (!cancelWaitingLine.empty())
                new StartBuyingTicket('c').schedule(time());
            else if (!reserveWaitingLine.empty())
                new StartBuyingTicket('r').schedule(time());
            noOfCustomers++;
            throughTime += time() - theCustomer.entryTime;
        }
    }


    public class CustomerCancelArrival extends Event {
        public void actions(){
            if (time() <= simPeriod) {
                Customer theCustomer = new Customer();
                theCustomer.into(cancelWaitingLine);
                int q2Length = cancelWaitingLine.cardinal();
                if (maxCancelLength < q2Length)
                    maxCancelLength = q2Length;
                if (!ticketBuyerIDLEQueu.empty())
                    new StartBuyingTicket('c').schedule(time());
                new CustomerCancelArrival().schedule(
                        time() + random.negexp(1 / 11.0));//11 = cancel-mean
            }
        }
    }

    public class CustomerExistanceOfReserveQueue extends Event {
        Customer theCustomer;
        public CustomerExistanceOfReserveQueue(Customer theCustomer) {
            this.theCustomer = theCustomer;
        }

        public void actions(){
            if (commingOut())
                reserveWaitingLine.remove(theCustomer);
        }

        private boolean commingOut() {
            //todo : check if the customer should come out
            return false;
        }
    }
}
